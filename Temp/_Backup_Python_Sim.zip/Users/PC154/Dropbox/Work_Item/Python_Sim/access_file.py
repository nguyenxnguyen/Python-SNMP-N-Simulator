from Tkinter import *
import tkFileDialog, tkMessageBox,  os, sys, re
import requests


class AccessFile(object):
    def __init__(self, *args, **kwargs):
        pass

    def check_version(self):
        folder = os.path.dirname(os.path.abspath(__file__))
        f_path = folder + '/Readme.txt'
        f_open = open(f_path, 'r')
        lines = f_open.read().splitlines()
        prefix_version = 'Python SNMP simulator ver '
        version = lines[0].replace(prefix_version, '')
        link = 'https://www.dropbox.com/s/rntyaxaaxn03oai/Readme.txt?dl=1'
        f_source = requests.get(link)
        f_text = f_source.text.split('\n')
        f_open.close()
        if f_text:
            for line in f_text:
                if prefix_version in line:
                    latest_version = line.replace(prefix_version, '')
                    if float(latest_version) > float(version):
                        msg = 'Version is %s available!\n Do you want to update?' % latest_version
                        ans = tkMessageBox.askyesno('New version!', message=msg)
                        yield ans
                        break

    def get_file(self):
        folder = tkFileDialog.askdirectory(initialdir=os.path.expanduser('~/Desktop'))
        #file_read = read_file(folder)
        #insert_table(folder, file_read)
        #if check_state.get() == 1:
        #    snmp_get_sysoid()
        file_path = folder + '/' + "List_of_Mibdumps.csv"
        file_read = []
        if os.path.exists(file_path):
            f = open(file_path, 'r')
            if f:
                f_read = f.read().split('\n')
                for f_line in f_read:
                    #print f_line
                    if '127' not in f_line:
                        continue
                    else:
                        file_read.append(f_line)
        else:
            pass
        return folder, file_read

    def write_file(self, file_name, body):
        f_path = os.path.dirname(os.path.abspath(__file__)) + "/" + file_name
        f_open = open(f_path, 'w')
        f_open.write(body)
        f_open.close()

