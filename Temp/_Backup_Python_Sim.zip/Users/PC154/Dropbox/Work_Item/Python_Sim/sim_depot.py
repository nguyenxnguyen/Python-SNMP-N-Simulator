from Tkinter import *
from string import join
import tkFileDialog, tkMessageBox,  os, sys, re
from MultiListbox import MultiListbox
import subprocess
import atexit
import signal
from time import sleep

@atexit.register
def goodbye():
    print("You are now leaving the Python SimSNMP.")


def insert_table():
    pass


def get_file():
    file = tkFileDialog.askopenfile(mode="r", initialdir=os.path.expanduser('~/Desktop'))
    file_read = open(file)
    insert_table()
    if check_state.get() == 1:
        snmp_get_sysoid()



def snmp_get_sysoid():
    snmpget = os.path.dirname(os.path.abspath(__file__)) + "/" + 'SnmpGet.exe'
    folder = os.path.dirname(os.path.abspath(__file__))
    msg_conflict = ''
    log_detail = ''
    if mlb.size() > 0:
        table = mlb.get(0, mlb.size() - 1)
        mlb.delete(0, mlb.size() - 1)
        sys_oid = '".1.3.6.1.2.1.1.2.0"'
        for row in table:
            row = list(row)
            cmd_snmpget = '\""%s" -q -r:%s -p:%s -t:1 -c:"public" -o:%s' % (snmpget, row[0], row[1], sys_oid)
            response = os.popen(cmd_snmpget).read()
            #print response
            if response.__contains__('Timeout'):
                state = 'Stopped'
                sys_oid_value = '---'
            elif response.__contains__('1.3.6.1.4.1'):
                state = 'Running'
                sys_oid_value = response
            else:
                state = 'Unknown'
                sys_oid_value = '---'
            row[3] = state
            if row[5] != '---' and row[5] != sys_oid_value and sys_oid_value != '---':
                msg_conflict += '%s:%s - %s\tSim has changed!\n' % (row[0], row[1], row[2])
            row[5] = sys_oid_value
            mlb.insert(END, ('%s' % row[0], '%s' % row[1], '%s' % row[2], '%s' % row[3], '%s' % row[4], '%s' % row[5]))
            mlb.pack(expand=YES, fill=BOTH)
            if state == 'Running':
                log_add = '%s,%s,%s,%s' % (row[0], row[1], row[2], sys_oid_value)
                log_detail += log_add
        log_path = folder + "/" + "List_of_simID.csv"
        log_open = open(log_path, 'w')
        log_open.write(log_detail)
        log_open.close()
        if msg_conflict != '':
            tkMessageBox.showwarning(title='Conflict!', message=msg_conflict)


def discover():
    username = user_entry.get()
    password = pass_entry.get()
    log_detail = ''
    if password == '':
        password = '1QAZ2wsx'
    if mlb.size() > 0:
        table = mlb.get(0, mlb.size() - 1)
        for row in table:
            row = list(row)
            sys_oid = row[4]
            dump_file = row[2]
            port = row[1]
            ip_address = row[0]
            cmd_dis = '"\"c:/Program Files (x86)/Nimsoft/bin/pu.exe\" -u %s -p ' \
                      '%s snmpcollector add_snmp_device ' \
                      '%s snmpv2c %s %s public "" "" "" "" ""' % (username, password, ip_address, dump_file, port)
            os.system(cmd_dis)
            log_add = '%s,%s,%s,%s' % (ip_address, port, dump_file, sys_oid)
            log_detail = log_detail + log_add + '\n'
    log_path = os.path.dirname(os.path.abspath(__file__)) + "/" + "List_of_Discovered_Devices.csv"
    log_open = open(log_path, 'w')
    log_open.write(log_detail)
    log_open.close()


def rm_device():
    username = user_entry.get()
    password = pass_entry.get()
    if password == '':
        password = '1QAZ2wsx'
    if mlb.size() > 0:
        table = mlb.get(0, mlb.size() - 1)
        for row in table:
            row = list(row)
            ip_address = row[0]
            cmd_remove = '"\"c:/Program Files (x86)/Nimsoft/bin/pu.exe" -u %s -p ' \
                         '%s snmpcollector remove_snmp_device "%s"' % (username, password, ip_address)
            os.system(cmd_remove)


root = Tk()
root.title("Launch SnmpSimN")

frame1 = Frame(root)
frame1.grid(column=1, row=1, columnspan=6)

frame2 = Frame(root)
frame2.grid(column=1, row=2, columnspan=6)

frame3 = Frame(root)
frame3.grid(column=1, row=3, columnspan=3)

frame4 = Frame(root)
frame4.grid(column=1, row=4, columnspan=1)

frame5 = Frame(root)
frame5.grid(column=1, row=5, columnspan=2)

frame6 = Frame(root)
frame6.grid(column=1, row=6, columnspan=1)

blank_label = Label(frame1, text="", width=5)
blank_label.grid(column=1, row=1)

# Browse file
file_label = Label(frame1, text="Dump folder:", width=15)
file_label.grid(column=2, row=1)
file_entry = Entry(frame1, width=120)
file_entry.insert(INSERT, file)
file_entry.grid(column=3, row=1)

blank_label = Label(frame1, text="", width=1)
blank_label.grid(column=4, row=1)

# Browse button
browse_button = Button(frame1, text="Browse", command=get_file, font=("Segoe UI", 7), width=12)
browse_button.grid(column=5, row=1)

blank_label = Label(frame1, text="", width=2)
blank_label.grid(column=6, row=1)


# V1 checkbox
v1 = IntVar()
v1CheckBox = Checkbutton(frame2, text="SNMPv1  ", variable=v1, font=('Segoe UI', 10), width=25)
v1CheckBox.select()
v1CheckBox.grid(column=1, row=1)

# V2 checkbox
v2c = IntVar()
v2cCheckBox = Checkbutton(frame2, text="SNMPv2c", variable=v2c, font=('Segoe UI', 10), width=25)
v2cCheckBox.select()
v2cCheckBox.grid(column=1, row=2)

# Port
port_label = Label(frame2, text="Port:          ", width=10)
port_label.grid(column=2, row=1)
port_entry = Entry(frame2, width=10)
port_entry.insert(INSERT, 161)
port_entry.grid(column=3, row=1)

# Check Status checkbox
check_state = IntVar()
stateCheckBox = Checkbutton(frame2, text="Auto-Checking Status", variable=check_state, font=('Segoe UI', 8), width=20)
#stateCheckBox.select()
stateCheckBox.grid(column=2, row=2)

# Username
user_label = Label(frame2, text="          User:        ", width=15)
user_label.grid(column=4, row=1)
user_entry = Entry(frame2, width=15)
user_entry.insert(INSERT, 'administrator')
user_entry.grid(column=5, row=1)

blank_label = Label(frame2, text="", width=5)
blank_label.grid(column=6, row=1)

# Password
pass_label = Label(frame2, text="          Password:", width=15)
pass_label.grid(column=4, row=2)
pass_entry = Entry(frame2, width=15, show="*")
pass_entry.grid(column=5, row=2)

blank_label = Label(frame2, text="", width=5)
blank_label.grid(column=6, row=2)

blank_label = Label(frame3, text="", width=5)
blank_label.grid(column=1, row=1)

# Discover button
discover_button = Button(frame3, text=" DISCOVER by UIM ", command=discover, font=('Segoe UI', 10), relief=RAISED)
discover_button.grid(column=5, row=1)

blank_label = Label(frame3, text="", width=5)
blank_label.grid(column=6, row=1)

# Check status button
run_button = Button(frame3, text=" CHECK STATUS ", command=snmp_get_sysoid, font=('Segoe UI', 10), relief=RAISED)
run_button.grid(column=7, row=1)

blank_label = Label(frame3, text="", width=1)
blank_label.grid(column=8, row=1)

blank_label = Label(frame4, text="", width=140)
blank_label.pack()

blank_label = Label(frame5, text="", width=2)
blank_label.pack(side=LEFT)
blank_label = Label(frame5, text="", width=1)
blank_label.pack(side=RIGHT)

# Table
Label(frame5, text='\n',).pack(side=RIGHT)
mlb = MultiListbox(frame5, 20, (('IP Adress', 15), ('Port', 10), ('Mibdump', 70), ('Status', 15),
                                ('PID', 10), ('Sys OID', 30)))
# Remove discovered device
rm_button = Button(frame6, text="Remove Discovered Devices", command=rm_device, font=('Segoe UI', 10), relief=RAISED)
rm_button.pack()

root.mainloop()
sys.exit(0)